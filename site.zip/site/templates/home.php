<?php 

/**
 * Homepage template
 *
 */

include("./page.php"); 
